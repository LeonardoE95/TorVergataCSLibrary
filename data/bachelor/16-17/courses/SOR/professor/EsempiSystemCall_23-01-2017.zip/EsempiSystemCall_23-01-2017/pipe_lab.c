/**
  Sistemi operativi e reti (SOR)
	@author Pietro Frasca
	@version 1.0 11-01-2016
	
  Laboratorio 22.05.2009 
	Il processo padre P genera due figli, P1 e P2. Ciascuno dei due figli esegue un ciclo infinito durante il quale genera numeri interi casuali compresi tra 0 e 100. Ad ogni estrazione ciascuno dei figli comunica il numero estratto al padre, il quale provvede a sommarli. Anche il padre esegue un ciclo infinito, durante il quale somma i numeri che ha ricevuto dai figli. Ad ogni ciclo, il padre deve sommare un numero estratto da P1 con quello estratto da P2. Non deve sommare due numeri di P1 o due numeri di P2. Inoltre, il padre P deve gestire il segnale SIGINT, in modo tale che ogni volta che riceve tale segnale visualizzi il valore corrente della somma. Il programma multiprocesso deve terminare quando il processo padre riceve tre volte il segnale SIGINT" 	
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
char buf[32];
int x,somma;

/* genera un numero casuale compreso tra min e max */
int getRandom(int min, int max) {
  return rand()%(max-min+1)+min;
}

/* Handler associato al segnale SIGINT */
void handler (int sig){
  static int cont=0;
  printf("Somma corrente = %d \n",somma);  
  cont++;
  if (cont == 3) {
    printf ("Termino il programma...");
    kill(0,SIGKILL); /* invia il segnale SIGKILL a tutti i processi (al padre e ai due figli) */
  }
}

int main() {
  int pd1[2], pd2[2]; /* descrittori delle due pipe usate per la comunicazione tra il padre e i figli */
  int pid1, pid2; /* identificatori (pid) dei due processi figli */
  
  /* creazione della prima pipe per la comunicazione tra il padre il figlio 1 (pid1) */
  if (pipe(pd1)<0) {
    printf("errore pipe1");
    exit(1);
  }

	/* creazione della seconda pipe per la comunicazione tra il padre il figlio 2 (pid2) */
  if (pipe(pd2)<0) {
     printf("errore pipe2");
    exit(1);
  }
  pid1=fork(); /* creazione del figlio 1 */
  switch(pid1) {
  case -1: printf("errore fork1");
    exit(1);
  case 0:
    // codice figlio 1
    srand(time(NULL)); 
    close(pd1[0]); /* Figlio 1 chiude l'estremo del canale che non usa */
    while (1) {
      x=getRandom(0,100); /* estrazione numero casuale */
      sprintf(buf,"%d",x); /* conversione di tipo da int a char[] */      
      write(pd1[1],buf,sizeof(buf)); /* scrittura del numero estratto (convertito) nella pipe 1 */
    }   
    break; 
  default:
    //codice padre
    
    pid2=fork(); /* creazione figlio 2 */
    if (pid2==0) {
      srand(time(NULL)+1); /* Sommare +1 a time(NULL) � necessario per avere numeri casuali 
		   	     diversi per i due figli */     
      close(pd2[0]); /* Figlio 2 chiude l'estremo del canale che non usa */
      while (1) {
         x=getRandom(0,100); /* estrazione numero casuale */
         sprintf(buf,"%d",x); /* conversione di tipo da int a char[] */  
         write(pd2[1],buf,sizeof(buf)); /* scrittura del numero estratto (convertito) nella pipe 2 */
      
      }   
     
    }
    signal (SIGINT,handler); /* gestione del segnale SIGINT. Quando il processo padre ricever� tale segnale sar� eseguita la funzione handler */	
    while (1) {
			read(pd1[0],buf,sizeof(buf)); //Il padre legge il numero estratto dal figlio 1
      printf("ricevo da figlio1: %s \n",buf);    
      somma+=atoi(buf);
      read(pd2[0],buf,sizeof(buf)); //Il padre legge il numero estratto dal figlio 2
      printf("ricevo da figlio2: %s \n",buf);
      somma+=atoi(buf);
      printf("somma = %d \n",somma);
      sleep(1);   
    }
  }
}
